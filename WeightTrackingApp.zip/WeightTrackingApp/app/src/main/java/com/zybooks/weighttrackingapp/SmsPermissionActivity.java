package com.zybooks.weighttrackingapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private Button btnAllowSMS, btnDenySMS;
    private EditText etPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        btnAllowSMS = findViewById(R.id.btnAllowSMS);
        btnDenySMS = findViewById(R.id.btnDenySMS);
        etPhoneNumber = findViewById(R.id.etPhoneNumber); // Get reference to phone number input field

        // "Allow SMS" button saves phone number and requests permission
        btnAllowSMS.setOnClickListener(view -> {
            String phoneNumber = etPhoneNumber.getText().toString().trim();

            if (phoneNumber.isEmpty()) {
                Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save phone number in SharedPreferences
            SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("phone_number", phoneNumber);
            editor.apply();

            // Now request SMS permission
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        });

        // "Deny SMS" button closes the screen and does not request permission
        btnDenySMS.setOnClickListener(view -> {
            Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            finish(); // Close activity if user denies permission
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
            finish(); // Close activity after permission request
        }
    }
}

