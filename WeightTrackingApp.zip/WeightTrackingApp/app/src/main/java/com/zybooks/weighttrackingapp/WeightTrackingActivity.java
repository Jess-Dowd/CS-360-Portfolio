package com.zybooks.weighttrackingapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.content.pm.PackageManager;
import android.widget.TextView;


public class WeightTrackingActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etDate, etWeight, etGoalWeight;
    private Button btnAddData, btnSetGoal;
    private RecyclerView recyclerView;
    private WeightAdapter weightAdapter;
    private List<WeightEntry> weightEntries;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "WeightPrefs";
    private static final String GOAL_WEIGHT_KEY = "goal_weight";
    private String loggedInUsername;
    private TextView tvCurrentGoal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new DatabaseHelper(this);
        etDate = findViewById(R.id.etDate);
        etWeight = findViewById(R.id.etWeight);
        etGoalWeight = findViewById(R.id.etGoalWeight);
        btnAddData = findViewById(R.id.btnAddData);
        btnSetGoal = findViewById(R.id.btnSetGoal);
        tvCurrentGoal = findViewById(R.id.tvCurrentGoal);

        TextView tvCurrentGoal = findViewById(R.id.tvCurrentGoal);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightEntries = new ArrayList<>();
        weightAdapter = new WeightAdapter(weightEntries, this::deleteEntry);
        recyclerView.setAdapter(weightAdapter);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);



        // Retrieve logged-in username ONCE when the activity starts
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        loggedInUsername = prefs.getString("LOGGED_IN_USER", null);

        if (loggedInUsername == null) {
            Toast.makeText(this, "Error: No user logged in", Toast.LENGTH_SHORT).show();
            finish(); // Closes the screen if no user is logged in
            return;
        }

        float savedGoalWeight = sharedPreferences.getFloat(GOAL_WEIGHT_KEY + "_" + loggedInUsername, -1);
        if (savedGoalWeight != -1) {
            tvCurrentGoal.setText("Current Goal: " + savedGoalWeight + " kg");
        } else {
            tvCurrentGoal.setText("Current Goal: -- kg"); // Reset for new user
        }


        // Set Goal Weight Button Click (unchanged)
        btnSetGoal.setOnClickListener(view -> {
            try {
                double goalWeight = Double.parseDouble(etGoalWeight.getText().toString());

                // Save the goal weight
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putFloat(GOAL_WEIGHT_KEY + "_" + loggedInUsername, (float) goalWeight);
                editor.apply();

                tvCurrentGoal.setText("Current Goal: " + goalWeight + " kg");

                Toast.makeText(this, "Goal Weight Set: " + goalWeight + " kg", Toast.LENGTH_SHORT).show();

                if (!checkSmsPermission()) {
                    Intent intent = new Intent(WeightTrackingActivity.this, SmsPermissionActivity.class);
                    startActivity(intent);
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        //Add Weight Entry Button Click (uses `loggedInUsername` directly now)
        btnAddData.setOnClickListener(view -> {
            String date = etDate.getText().toString();
            double weight;

            try {
                weight = Double.parseDouble(etWeight.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid weight", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add weight entry and then check goal weight
            if (dbHelper.addWeightEntry(loggedInUsername, date, weight)) {
                Toast.makeText(this, "Weight Entry Added", Toast.LENGTH_SHORT).show();

                checkGoalWeight(weight);

                loadWeightEntries(); // Refresh the list
            } else {
                Toast.makeText(this, "Error Adding Entry", Toast.LENGTH_SHORT).show();
            }
        });

        // Load the user's weight entries
        loadWeightEntries();
    }


    private void checkGoalWeight(double newWeight) {
        float goalWeight = sharedPreferences.getFloat(GOAL_WEIGHT_KEY + "_" + loggedInUsername, -1);
        if (goalWeight != -1 && newWeight == goalWeight) {
            sendGoalReachedNotification();
        }
    }


    private void sendGoalReachedNotification() {
        if (!checkSmsPermission()) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 102);
            return;
        }

        // Retrieve saved phone number
        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number saved for SMS notifications", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, "Congrats! You've reached your goal weight!", null, null);
            Toast.makeText(this, "Goal Reached! SMS Sent to " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error sending SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private boolean checkSmsPermission() {
        return checkSelfPermission(android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void loadWeightEntries() {
        weightEntries.clear();

        //Retrieve logged-in username from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String loggedInUsername = prefs.getString("LOGGED_IN_USER", null);

        if (loggedInUsername == null) {
            Toast.makeText(this, "Error: No user logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor cursor = dbHelper.getAllWeightEntries(loggedInUsername); // Pass username to filter data
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(2);
                double weight = cursor.getDouble(3);
                weightEntries.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
        }
        cursor.close();
        weightAdapter.notifyDataSetChanged();
    }


    private void deleteEntry(WeightEntry entry) {
        if (dbHelper.deleteWeightEntry(entry.getId())) {
            weightEntries.remove(entry);
            weightAdapter.notifyDataSetChanged();
            Toast.makeText(this, "Entry Deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error Deleting Entry", Toast.LENGTH_SHORT).show();
        }
    }
}
