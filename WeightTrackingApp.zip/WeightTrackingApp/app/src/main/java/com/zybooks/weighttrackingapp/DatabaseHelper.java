package com.zybooks.weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 2;

    // User Table
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Weight Table
    private static final String TABLE_WEIGHT = "weight_entries";
    private static final String COL_ID = "id";
    private static final String COL_DATE = "date";
    private static final String COL_WEIGHT = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE users (" +
                "username TEXT PRIMARY KEY, " +
                "password TEXT)";

        // username column to track which user owns each entry
        String createWeightTable = "CREATE TABLE weight_entries (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " + // New column
                "date TEXT, " +
                "weight REAL, " +
                "FOREIGN KEY (username) REFERENCES users(username))"; // Foreign key

        db.execSQL(createUserTable);
        db.execSQL(createWeightTable);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE username=? AND password=?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean addWeightEntry(String username, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username); // 🔥 Store the username
        values.put("date", date);
        values.put("weight", weight);
        long result = db.insert("weight_entries", null, values);
        return result != -1;
    }

    public Cursor getAllWeightEntries(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM weight_entries WHERE username=?", new String[]{username});
    }

    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHT, "id=?", new String[]{String.valueOf(id)}) > 0;
    }
}
