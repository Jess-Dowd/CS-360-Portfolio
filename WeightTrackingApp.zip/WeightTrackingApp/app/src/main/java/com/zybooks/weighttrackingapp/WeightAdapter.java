package com.zybooks.weighttrackingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<WeightEntry> weightEntries;
    private OnDeleteClickListener deleteClickListener;

    public WeightAdapter(List<WeightEntry> weightEntries, OnDeleteClickListener deleteClickListener) {
        this.weightEntries = weightEntries;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.tvWeight.setText(entry.getWeight() + " kg");
        holder.tvDate.setText(entry.getDate());

        holder.btnDelete.setOnClickListener(view -> deleteClickListener.onDeleteClick(entry));
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(WeightEntry entry);
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView tvWeight, tvDate;
        Button btnDelete;

        public WeightViewHolder(View itemView) {
            super(itemView);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
